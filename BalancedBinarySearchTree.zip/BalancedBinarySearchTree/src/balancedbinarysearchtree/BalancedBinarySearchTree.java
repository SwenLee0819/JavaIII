/*
Name :                  Ke Swen Lee
Student ID :            30010827
Date :                  31/07/2020
 */
package balancedbinarysearchtree;

import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class BalancedBinarySearchTree {

    public static void main(String[] args) {
        Tree myTree = new Tree();
        insertData(myTree);
        myTree.display();
        System.out.println();
        String result = displayMenu();
        System.out.println();

        while (!result.equals("Q")) {
            switch (result) {
                case "A":
                    myTree.add(newItem());
                    break;
                case "D":
                    myTree.delete(deleteItem());
                    break;
                case "F":
                    myTree.find(findItem());
                    break;
                default:
                    System.out.println("Invalid input. Please try again.");
                    break;
            }
            if (!result.equals("F")) {
                System.out.println();
                myTree.display();
                System.out.println();
                result = displayMenu();
                System.out.println();
            } else {
                System.out.println();
                result = displayMenu();
                System.out.println();
            }
        }

        if (result.equals("Q")) {
            System.out.println("Thanks, see you soon!");
        }
    }

    private static void insertData(Tree myTree) {
        try {
            String[] data = new String[15];

            data[0] = "Engine";
            data[1] = "Idler";
            data[2] = "Hasp";
            data[3] = "Chains";
            data[4] = "Joints";
            data[5] = "Motor";
            data[6] = "Detent";
            data[7] = "Fillet";
            data[8] = "Gears";
            data[9] = "Accelerator";
            data[10] = "Keyseat";
            data[11] = "Light";
            data[12] = "Odometer";
            data[13] = "Nails";
            data[14] = "Bolts";

            for (int i = 0; i < 15; i++) {
                myTree.add(data[i]);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private static String findItem() {
        try {
            Scanner sc = new Scanner(System.in);
            System.out.print("Please input mechanical part to search: ");
            String target = sc.next();
            return target;

        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    private static String deleteItem() {
        try {
            Scanner sc = new Scanner(System.in);
            System.out.print("Please input item to delete: ");
            String target = sc.next();
            return target;

        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    private static String newItem() {
        try {
            Scanner sc = new Scanner(System.in);
            System.out.print("Please input item to add: ");
            String data = sc.next();
            return data;

        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    private static String displayMenu() {
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("(A)dd name");
            System.out.println("(D)elete name");
            System.out.println("(F)ind name");
            System.out.println("(Q)uit");
            System.out.println();
            System.out.print("Please select an option: ");
            String result = sc.next();
            return result;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    @Test
    public static void doTest() {
        Tree testTree = new Tree();
        insertData(testTree);

        assertTrue((testTree.root.data).equals("Hasp"));
    }
}
