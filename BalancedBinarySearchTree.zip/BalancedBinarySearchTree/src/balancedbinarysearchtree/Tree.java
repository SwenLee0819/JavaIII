package balancedbinarysearchtree;

public class Tree {

    class Node {

        Node left;
        String data;
        Node right;

        public Node(String data) {
            this.data = data;
        }
    }

    Node root;

    public Tree() {
    }

    public void add(String data) {
        try {
            Node newItem = new Node(data);
            if (root == null) {
                root = newItem;
            } else {
                root = addRecursive(root, newItem);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private Node addRecursive(Node current, Node n) {
        if (current == null) {
            current = n;
            return current;
        } else if (n.data.compareTo(current.data) < 0) {
            current.left = addRecursive(current.left, n);
            current = balanceTree(current);
        } else if (n.data.compareTo(current.data) > 0) {
            current.right = addRecursive(current.right, n);
            current = balanceTree(current);
        } else {
            // Data exists
            return current;
        }
        return current;
    }

    public void delete(String target) {
        try {
            root = deleteNode(root, target);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private Node deleteNode(Node current, String target) {
        Node parent;
        if (current == null) {
            return null;
        } else {
            // Left subtree
            if (target.compareTo(current.data) < 0) {
                current.left = deleteNode(current.left, target);
                if (balanceFactor(current) == -2) {
                    if (balanceFactor(current.right) <= 0) {
                        current = rotateRR(current);
                    } else {
                        current = rotateRL(current);
                    }
                }
                return current;
            } // Right subtree
            else if (target.compareTo(current.data) > 0) {
                current.right = deleteNode(current.right, target);
                if (balanceFactor(current) == 2) {
                    if (balanceFactor(current.left) >= 0) {
                        current = rotateLL(current);
                    } else {
                        current = rotateLR(current);
                    }
                }
                return current;
            } else { // If the target is found
                if (current.right != null) {
                    // Delete its inorder successor
                    parent = current.right;
                    while (parent.left != null) {
                        parent = parent.left;
                    }
                    current.data = parent.data;
                    current.right = deleteNode(current.right, parent.data);
                    // Rebalance
                    if (balanceFactor(current) == -2) {
                        if (balanceFactor(current.left) >= 0) {
                            current = rotateLL(current);
                        } else {
                            current = rotateLR(current);
                        }
                    }
                    return current;
                } else {
                    return current.left;
                }
            }
        }
    }

    private Node balanceTree(Node current) {
        int b_factor = balanceFactor(current);
        if (b_factor > 1) {
            if (balanceFactor(current.left) > 0) {
                current = rotateLL(current);
            } else {
                current = rotateLR(current);
            }
        } else if (b_factor < -1) {
            if (balanceFactor(current.right) > 0) {
                current = rotateRL(current);
            } else {
                current = rotateRR(current);
            }
        }
        return current;
    }

    private int balanceFactor(Node current) {
        int l = getHeight(current.left);
        int r = getHeight(current.right);
        int b_factor = l - r;
        return b_factor;
    }

    private Node rotateRR(Node parent) {
        Node pivot = parent.right;
        parent.right = pivot.left;
        pivot.left = parent;
        return pivot;
    }

    private Node rotateLL(Node parent) {
        Node pivot = parent.left;
        parent.left = pivot.right;
        pivot.right = parent;
        return pivot;
    }

    private Node rotateLR(Node parent) {
        Node pivot = parent.left;
        parent.left = rotateRR(pivot);
        return rotateLL(parent);
    }

    private Node rotateRL(Node parent) {
        Node pivot = parent.right;
        parent.right = rotateLL(pivot);
        return rotateRR(parent);
    }

    private int max(int l, int r) {
        return l > r ? l : r;
    }

    private int getHeight(Node current) {
        int height = 0;
        if (current != null) {
            int l = getHeight(current.left);
            int r = getHeight(current.right);
            int m = max(l, r);
            height = m + 1;
        }
        return height;
    }

    public void find(String key) {
        try {
            if (findRecursive(key, root).data.equals(key)) {
                System.out.println(key + " was found!");
            }
        } catch (Exception e) {
            System.out.println(key + " was not found!");
        }
    }

    private Node findRecursive(String target, Node current) {
        if (target.compareTo(current.data) < 0) {
            if (target.equals(current.data)) {
                return current;
            } else {
                return findRecursive(target, current.left);
            }
        } else {
            if (target.equals(current.data)) {
                return current;
            } else {
                return findRecursive(target, current.right);
            }
        }
    }

    public void display() {
        try {
            System.out.println("---------------- Tree ----------------");
            if (root == null) {
                System.out.println("Tree is empty");
                return;
            }
            System.out.println("Root: " + root.data);
            displayInOrder(root);
            System.out.println("-------------- End Tree --------------");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void displayInOrder(Node current) {
        try {
            if (current != null) {
                displayInOrder(current.left);
                displayInOrder(current.right);
                System.out.println("[" + current.data + "] ");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
