/*
Name :                  Ke Swen Lee
Student ID :            30010827
Date :                  28/07/2020
 */
package doublylinkedlist;

class Node {

    String prev;
    String data;
    String next;

    public String printData() {

        String output = null;

        if ("Australia".equals(data)) {
            output = "Perth, Sydney, Melbourne, Adelaide, Brisbane ...";
        } else if ("China".equals(data)) {
            output = "Beijing, Shanghai, Wuhan, Shenzhen, Chongqing ...";
        } else if ("United Kingdom".equals(data)) {
            output = "London, Manchester, Edinburgh, Birmingham, Glasgow ...";
        } else if ("New Zealand".equals(data)) {
            output = "Auckland, Wellington, Dunedin, Hamilton, Queenstown ...";
        } else {
            output = "";
        }

        return "Country: " + data + "\r\nCities: " + output;
    }
}

public class DoublyLinkedList {

    public static void main(String[] args) {

        Node node1 = new Node();
        Node node2 = new Node();
        Node node3 = new Node();
        Node node4 = new Node();

        node1.prev = null;
        node1.data = "Australia";

        node2.prev = node1.data;
        node2.data = "China";
        node1.next = node2.data;

        node3.prev = node2.data;
        node3.data = "United Kingdom";
        node2.next = node3.data;

        node4.prev = node3.data;
        node4.data = "New Zealand";
        node3.next = node4.data;
        node4.next = null;

        System.out.println(node1.printData());
        System.out.println();
        System.out.println(node2.printData());
        System.out.println();
        System.out.println(node3.printData());
        System.out.println();
        System.out.println(node4.printData());
    }

}
